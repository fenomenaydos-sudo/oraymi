package com.oraymi.nativeapp

import android.content.Context
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

/** Monotonic time measurement; state survives Activity recreation. */
class TimerStore(context: Context) {
    private val prefs = context.getSharedPreferences("oraymi_native", Context.MODE_PRIVATE)
    fun isRunning(): Boolean = prefs.getBoolean("running", false)
    fun category(): String = prefs.getString("category", "Фокус") ?: "Фокус"
    fun millis(): Long {
        val base = prefs.getLong("elapsed", 0L)
        if (!isRunning()) return base
        val since = prefs.getLong("started", 0L)
        val now = SystemClock.elapsedRealtime()
        return base + if (since > now || since <= 0L) 0L else now - since
    }
    fun start(category: String? = null) {
        val cat = category ?: category()
        if (isRunning()) return
        prefs.edit().putString("category", cat).putLong("started", SystemClock.elapsedRealtime())
            .putBoolean("running", true).apply()
    }
    fun pause() {
        val total = millis()
        prefs.edit().putLong("elapsed", total).putBoolean("running", false).remove("started").apply()
    }
    fun finish(): Long {
        val total = millis()
        if (total >= 1000L) {
            val history = history()
            val item = JSONObject().put("at", System.currentTimeMillis())
                .put("category", category()).put("millis", total)
            history.put(item)
            prefs.edit().putString("history", history.toString()).apply()
        }
        prefs.edit().putLong("elapsed", 0).putBoolean("running", false).remove("started").apply()
        return total
    }
    fun chooseCategory(category: String) {
        if (category != category() && millis() > 0L) finish() // Archive previous activity; never mix categories.
        prefs.edit().putString("category", category).apply()
    }
    fun history(): JSONArray = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
}

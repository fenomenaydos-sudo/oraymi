package com.oraymi.nativeapp

import java.util.Locale

/** Private, deterministic command router. This is NOT a general conversation AI. */
object IntentParser {
    enum class Action { WAKE, START, PAUSE, RESUME, FINISH, NONE }
    data class Result(val action: Action, val hasWakeWord: Boolean)

    fun parse(raw: String): Result {
        val s = raw.lowercase(Locale.ROOT)
            .replace('ё', 'е').replace(Regex("[^\\p{L}\\p{N} ]"), " ")
            .replace(Regex("\\s+"), " ").trim()
        fun has(vararg items: String) = items.any { s.contains(it) }
        val wake = has("бадди", "беди", "бади", "бэди", "пати", "buddy", "орайми", "oraymi", "пиди", "пд ")
        // Safety first: never treat "don't stop" as a command to stop.
        if (has("не ставь", "не останавливай", "не завершай", "не выключай", "do not stop", "don't stop", "nicht stoppen")) {
            // Explicit request to pause the TIMER can still win over negation about MUSIC.
            if (!(has("пауз") && has("трениров", "таймер", "занятие")))
                return Result(if (wake) Action.WAKE else Action.NONE, wake)
        }
        if (has("музыку", "песню", "видео", "music", "song", "video") && !has("таймер", "тренировку", "занятие"))
            return Result(if (wake) Action.WAKE else Action.NONE, wake)
        val result = when {
            has("заверши", "закончил", "закончили", "заканчиваем", "сохрани результат", "на сегодня все", "я закончил", "аякт", "бітір", "finish session", "end session", "fertig") -> Action.FINISH
            has("пауза", "паузу", "стоп", "останов", "подожди", "хватит", "тоқта", "токта", "pause", "halt", "stop", "warte") -> Action.PAUSE
            has("продолж", "дальше", "возобнов", "жалғаст", "жалгаст", "resume", "continue", "weiter") -> Action.RESUME
            has("начни", "начина", "давай нач", "запусти", "старт", "баста", "start", "begin", "los geht") -> Action.START
            else -> if (wake) Action.WAKE else Action.NONE
        }
        return Result(result, wake)
    }
}

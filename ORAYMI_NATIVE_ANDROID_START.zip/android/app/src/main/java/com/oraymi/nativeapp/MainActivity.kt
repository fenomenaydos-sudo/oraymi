package com.oraymi.nativeapp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowInsets
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** First real native milestone: accurate timer + opt-in hands-free session. */
class MainActivity : Activity() {
    private lateinit var timer: TimerStore
    private lateinit var orbit: OrbitView
    private lateinit var timerState: TextView
    private lateinit var voiceState: TextView
    private lateinit var voiceButton: TextView
    private val main = Handler(Looper.getMainLooper())
    private val bg = Color.rgb(9,14,31)
    private val muted = Color.rgb(159,175,197)
    private val mint = Color.rgb(121,236,198)
    private val purple = Color.rgb(171,144,255)
    private val prefs by lazy { getSharedPreferences("oraymi_native", MODE_PRIVATE) }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private val refresh = object:Runnable {
        override fun run() { updateUi(); main.postDelayed(this,350) }
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=bg;window.navigationBarColor=bg
        timer=TimerStore(this)
        render()
    }
    override fun onResume() { super.onResume(); main.removeCallbacks(refresh);main.post(refresh) }
    override fun onPause() { main.removeCallbacks(refresh); super.onPause() }
    private fun shape(fill:Int, outline:Int=Color.TRANSPARENT, radius:Int=22):GradientDrawable =
        GradientDrawable().apply { setColor(fill);cornerRadius=dp(radius).toFloat();if(outline!=Color.TRANSPARENT)setStroke(dp(1),outline) }
    private fun text(label:String,sp:Float=16f,color:Int=Color.WHITE,bold:Boolean=false):TextView =
        TextView(this).apply {text=label;textSize=sp;setTextColor(color);if(bold)typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER_VERTICAL}
    private fun panel():LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        background=GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(22,42,62),Color.rgb(22,31,58),Color.rgb(26,25,48))).apply {
            cornerRadius=dp(23).toFloat();setStroke(dp(1),Color.rgb(61,91,109))
        }
        setPadding(dp(17),dp(17),dp(17),dp(17))
    }
    private fun columnGap(parent:LinearLayout,h:Int=12) { parent.addView(View(this),LinearLayout.LayoutParams(1,dp(h))) }
    private fun button(label:String,color:Int=0,action:()->Unit):TextView = text(label,14f,Color.WHITE,true).apply {
        gravity=Gravity.CENTER
        background=shape(if(color==0)Color.rgb(39,51,79) else color,Color.rgb(67,91,115),15)
        setPadding(dp(9),dp(12),dp(9),dp(12));setOnClickListener{action()}
    }
    private fun horizontal():LinearLayout=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
    private fun rowAdd(row:LinearLayout,view:View,weight:Float=1f) {
        row.addView(view,LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,weight))
    }
    private fun render() {
        val scroll=ScrollView(this).apply {fillViewport=true;isVerticalScrollBarEnabled=false;setBackgroundColor(bg)}
        val root=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(20))}
        scroll.addView(root)
        if (Build.VERSION.SDK_INT >= 30) {
            scroll.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        } else scroll.fitsSystemWindows = true
        setContentView(scroll)
        val header=horizontal()
        val brand=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
        brand.addView(text("O R A Y M I",26f,Color.WHITE,true))
        brand.addView(text("NATIVE • VOICE ALPHA",10f,mint,true))
        header.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        header.addView(text("●  BUDDY",12f,mint,true).apply {gravity=Gravity.CENTER;setPadding(dp(10),dp(8),dp(10),dp(8));background=shape(Color.rgb(22,49,61),Color.rgb(58,102,109),20)})
        root.addView(header)
        columnGap(root,19)

        val buddy=panel();val budrow=horizontal()
        budrow.addView(BuddyPortrait(this))
        val budtext=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(8),0,0,0)}
        budtext.addView(text("Привет! Я BUDDY 💚",17f,Color.WHITE,true))
        budtext.addView(text("Голос без повторных нажатий — тестовый режим",12f,muted))
        budrow.addView(budtext,LinearLayout.LayoutParams(0,-2,1f))
        buddy.addView(budrow)
        columnGap(buddy,12)
        voiceState=text("Микрофон выключен",13f,muted)
        buddy.addView(voiceState)
        columnGap(buddy,10)
        voiceButton=button("🎙  Включить BUDDY",Color.rgb(19,93,91)) { toggleVoice() }
        buddy.addView(voiceButton)
        buddy.addView(text("Микрофон работает только с твоего разрешения; выключить можно и через уведомление.",11f,muted).apply {setPadding(0,dp(8),0,0)})
        root.addView(buddy)
        columnGap(root,15)

        val focus=panel()
        val title=horizontal()
        title.addView(text("ТВОЙ ORBIT",13f,mint,true),LinearLayout.LayoutParams(0,-2,1f))
        timerState=text("Готов к занятию",12f,muted)
        title.addView(timerState)
        focus.addView(title)
        columnGap(focus,4)
        orbit=OrbitView(this)
        focus.addView(orbit,LinearLayout.LayoutParams(-1,dp(235)))
        val actionrow=horizontal()
        rowAdd(actionrow,button("▶  Старт",Color.rgb(17,95,84)){ timer.start();updateUi() })
        actionrow.addView(View(this),LinearLayout.LayoutParams(dp(8),1))
        rowAdd(actionrow,button("Ⅱ  Пауза"){timer.pause();updateUi()})
        actionrow.addView(View(this),LinearLayout.LayoutParams(dp(8),1))
        rowAdd(actionrow,button("✓  Завершить",Color.rgb(62,45,99)){
            val m=timer.finish();updateUi()
            Toast.makeText(this,if(m>0)"Занятие сохранено" else "Таймер очищен",Toast.LENGTH_SHORT).show()
        })
        focus.addView(actionrow)
        root.addView(focus)
        columnGap(root,17)

        root.addView(text("Чем займёмся?",19f,Color.WHITE,true))
        columnGap(root,9)
        val categories=horizontal()
        listOf("Учёба","Спорт","Работа","Отдых").forEachIndexed { i,cat->
            if(i>0)categories.addView(View(this),LinearLayout.LayoutParams(dp(5),1))
            rowAdd(categories,button(cat){
                if (cat != timer.category() && timer.millis() > 0L) {
                    AlertDialog.Builder(this).setTitle("Сменить занятие?")
                        .setMessage("Сохранить прежнее занятие и переключиться на «$cat»?")
                        .setPositiveButton("Сохранить") { _, _ -> timer.chooseCategory(cat);updateUi() }
                        .setNegativeButton("Отмена", null).show()
                } else { timer.chooseCategory(cat);updateUi() }
            })
        }
        root.addView(categories)
        columnGap(root,14)

        val history=horizontal()
        rowAdd(history,button("◷  История занятий") { showHistory() })
        history.addView(View(this),LinearLayout.LayoutParams(dp(9),1))
        rowAdd(history,button("🌐  ORAYMI 5.2") {
            // Open the existing web app in its original browser origin: old data remains there.
            startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://fenomenaydos-sudo.github.io/oraymi/")))
        })
        root.addView(history)
        columnGap(root,13)
        root.addView(text("Пока это первый Android-прототип. Квесты, финансы и предыдущие записи доступны в веб-версии; перенос данных добавим отдельно.",12f,muted))
    }
    private fun updateUi() {
        if (!::orbit.isInitialized) return
        orbit.duration=timer.millis(); orbit.label=timer.category();orbit.active=timer.isRunning();orbit.invalidate()
        timerState.text=if(timer.isRunning())"Идёт отсчёт" else if(timer.millis()>0)"Пауза" else "Готов к занятию"
        val active=prefs.getBoolean("voice_active",false)
        voiceState.text=prefs.getString("voice_status",if(active)"BUDDY слушает" else "Микрофон выключен")
        voiceButton.text=if(active)"■  Выключить BUDDY" else "🎙  Включить BUDDY"
    }
    private fun toggleVoice() {
        if (prefs.getBoolean("voice_active",false)) {
            startService(Intent(this,BuddyVoiceService::class.java).setAction(BuddyVoiceService.STOP))
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            val permissions=mutableListOf(Manifest.permission.RECORD_AUDIO)
            if(Build.VERSION.SDK_INT>=33)permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(permissions.toTypedArray(),42)
        } else launchVoice()
    }
    private fun launchVoice() {
        try { startForegroundService(Intent(this,BuddyVoiceService::class.java).setAction(BuddyVoiceService.START)) }
        catch(e:Exception){ Toast.makeText(this,"Не удалось включить микрофон: ${e.javaClass.simpleName}",Toast.LENGTH_LONG).show() }
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==42 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) launchVoice()
    }
    private fun showHistory() {
        val list=timer.history()
        if(list.length()==0) {
            AlertDialog.Builder(this).setTitle("История занятий").setMessage("Пока нет завершённых занятий.").setPositiveButton("Понятно",null).show();return
        }
        val format=SimpleDateFormat("dd.MM HH:mm",Locale.getDefault())
        val rows=(list.length()-1 downTo maxOf(0,list.length()-15)).map { i ->
            val item=list.getJSONObject(i)
            val dur=item.optLong("millis")/1000L
            "${format.format(Date(item.optLong("at")))}  •  ${item.optString("category")}  •  ${dur/60} мин ${dur%60} сек"
        }.joinToString("\n")
        AlertDialog.Builder(this).setTitle("История занятий").setMessage(rows)
            .setPositiveButton("Закрыть",null).show()
    }
}

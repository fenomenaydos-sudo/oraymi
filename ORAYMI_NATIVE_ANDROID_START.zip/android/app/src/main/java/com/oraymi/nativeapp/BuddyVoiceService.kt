package com.oraymi.nativeapp

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Opt-in foreground microphone session. DOES NOT claim an always-available wake word.
 * Android's system recognizer may stop or require internet; the user can stop it
 * from the persistent notification at any time. No raw audio is stored by ORAYMI.
 */
class BuddyVoiceService : Service(), RecognitionListener {
    companion object {
        const val START = "com.oraymi.nativeapp.VOICE_START"
        const val STOP = "com.oraymi.nativeapp.VOICE_STOP"
        private const val CHANNEL = "buddy_voice"
        private const val NOTIFICATION_ID = 9001
    }
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("oraymi_native", MODE_PRIVATE) }
    private var recognizer: SpeechRecognizer? = null
    private var voiceEnabled = false
    private var isListening = false
    private var errors = 0
    private var forceSystemRecognizer = false
    private var armedUntil = 0L
    private val tone by lazy { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 35) }
    private val restart = Runnable { if (voiceEnabled) startRecognition() }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { endVoiceSession(); return START_NOT_STICKY }
        if (intent?.action != START) return START_NOT_STICKY
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status("Нужно разрешить микрофон"); stopSelf(); return START_NOT_STICKY
        }
        createChannel()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else startForeground(NOTIFICATION_ID, notification())
        } catch (_: Exception) {
            status("Android не разрешил включить фоновый микрофон")
            stopSelf(); return START_NOT_STICKY
        }
        voiceEnabled = true
        prefs.edit().putBoolean("voice_active", true).apply()
        status("Бадди слушает, скажи «Бадди»")
        startRecognition()
        return START_NOT_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val mgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            mgr.createNotificationChannel(NotificationChannel(CHANNEL, "Голосовой BUDDY", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(): Notification {
        val stopIntent = Intent(this, BuddyVoiceService::class.java).setAction(STOP)
        val stopPi = PendingIntent.getService(this, 11, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val launch = PendingIntent.getActivity(this, 12,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ORAYMI • BUDDY")
            .setContentText("Микрофон включён по твоему разрешению")
            .setContentIntent(launch)
            .addAction(Notification.Action.Builder(null, "Выключить", stopPi).build())
            .setOngoing(true).build()
    }
    private fun status(value: String) { prefs.edit().putString("voice_status", value).apply() }
    private fun startRecognition() {
        if (!voiceEnabled || isListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("На телефоне нет доступного распознавания речи")
            endVoiceSession(); return
        }
        try {
            if (recognizer == null) {
                recognizer = if (!forceSystemRecognizer && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                } else SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(this)
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            }
            isListening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) { isListening = false; retry(2000) }
    }
    private fun retry(ms: Long) { handler.removeCallbacks(restart); if (voiceEnabled) handler.postDelayed(restart, ms) }
    private fun endVoiceSession() {
        voiceEnabled = false
        handler.removeCallbacks(restart)
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null; isListening = false
        prefs.edit().putBoolean("voice_active", false).apply()
        status("Микрофон выключен")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    override fun onDestroy() {
        voiceEnabled = false
        handler.removeCallbacks(restart)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        prefs.edit().putBoolean("voice_active", false).apply()
        try { tone.release() } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onReadyForSpeech(params: Bundle?) { errors = 0 }
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {
        isListening = false
        if (!voiceEnabled) return
        errors++
        if (Build.VERSION.SDK_INT >= 31 && !forceSystemRecognizer &&
            (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
            forceSystemRecognizer = true
            try { recognizer?.destroy() } catch (_: Exception) {}
            recognizer = null
            status("Офлайн-язык недоступен; пробую системное распознавание")
            retry(800)
            return
        }
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS || errors >= 16) {
            status("Распознавание остановилось. Включи режим ещё раз")
            endVoiceSession(); return
        }
        // Recognizer isn't a continuous wake-word API: short gaps are expected.
        retry(if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 650 else 1500)
    }
    override fun onResults(results: Bundle?) {
        isListening = false
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        if (phrases.isNotEmpty()) handlePhrase(phrases.first())
        retry(650)
    }
    private fun handlePhrase(phrase: String) {
        val item = IntentParser.parse(phrase)
        val now = SystemClock.elapsedRealtime()
        val gateOpen = item.hasWakeWord || now <= armedUntil
        if (!gateOpen) return
        if (item.action == IntentParser.Action.WAKE) {
            armedUntil = now + 8000
            try { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 100) } catch (_: Exception) {}
            status("Слушаю. Скажи команду")
            return
        }
        if (item.action == IntentParser.Action.NONE) {
            status("Не поняла команду. Скажи: пауза, продолжай или заверши")
            return
        }
        armedUntil = 0L
        val timer = TimerStore(this)
        when (item.action) {
            IntentParser.Action.PAUSE -> { timer.pause(); status("Пауза. Прогресс сохранён") }
            IntentParser.Action.START, IntentParser.Action.RESUME -> { timer.start(); status("Таймер идёт") }
            IntentParser.Action.FINISH -> {
                val elapsed = timer.finish()
                status(if (elapsed > 0) "Занятие завершено и сохранено" else "Таймер сброшен")
            }
            else -> {}
        }
    }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}

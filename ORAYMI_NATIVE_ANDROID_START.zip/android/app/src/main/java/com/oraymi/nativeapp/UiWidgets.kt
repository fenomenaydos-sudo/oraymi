package com.oraymi.nativeapp

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

class BuddyPortrait(context: Context): View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(widthMeasureSpec:Int, heightMeasureSpec:Int) {
        val px=(112*resources.displayMetrics.density).toInt()
        setMeasuredDimension(px,px)
    }
    override fun onDraw(canvas: Canvas) {
        val w=width.toFloat(); val h=height.toFloat(); val r=min(w,h)*.43f
        val cx=w/2;val cy=h/2
        paint.style=Paint.Style.FILL
        paint.shader=RadialGradient(cx-r*.3f,cy-r*.3f,r*2,intArrayOf(Color.rgb(169,255,231),Color.rgb(68,212,198),Color.rgb(37,96,140)),null,Shader.TileMode.CLAMP)
        canvas.drawCircle(cx,cy,r,paint);paint.shader=null
        paint.color=Color.rgb(8,36,53)
        canvas.drawOval(cx-r*.46f,cy-r*.15f,cx-r*.20f,cy+r*.17f,paint)
        canvas.drawOval(cx+r*.20f,cy-r*.15f,cx+r*.46f,cy+r*.17f,paint)
        paint.style=Paint.Style.STROKE;paint.strokeWidth=4*resources.displayMetrics.density;paint.strokeCap=Paint.Cap.ROUND
        val mouth=Path().apply { moveTo(cx-r*.23f,cy+r*.25f);quadTo(cx,cy+r*.5f,cx+r*.23f,cy+r*.25f) }
        canvas.drawPath(mouth,paint);paint.style=Paint.Style.FILL
        paint.color=Color.rgb(221,255,247)
        canvas.drawCircle(cx-r*.38f,cy-r*.34f,r*.07f,paint)
        canvas.drawCircle(cx+r*.33f,cy-r*.34f,r*.05f,paint)
    }
}

class OrbitView(context: Context): View(context) {
    var label="Фокус"
    var duration=0L
    var active=false
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(widthMeasureSpec:Int,heightMeasureSpec:Int) {
        val target=(248*resources.displayMetrics.density).toInt()
        val size=resolveSize(target,widthMeasureSpec)
        setMeasuredDimension(size,size)
    }
    override fun onDraw(canvas:Canvas) {
        val cx=width/2f;val cy=height/2f;val r=min(width,height)*.415f
        val stroke=11*resources.displayMetrics.density
        paint.style=Paint.Style.STROKE;paint.strokeWidth=stroke
        paint.color=Color.rgb(42,57,88);canvas.drawCircle(cx,cy,r,paint)
        paint.shader=SweepGradient(cx,cy,intArrayOf(Color.rgb(96,247,209),Color.rgb(144,153,255),Color.rgb(96,247,209)),null)
        val span = if (active) 290f else 145f
        canvas.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,span,false,paint)
        paint.shader=null;paint.style=Paint.Style.FILL
        paint.color=Color.rgb(17,24,49);canvas.drawCircle(cx,cy,r-stroke,paint)
        val density=resources.displayMetrics.density
        paint.color=Color.rgb(140,234,224);paint.textAlign=Paint.Align.CENTER
        paint.typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
        paint.textSize=13*density;canvas.drawText("O R B I T",cx,cy-48*density,paint)
        val secs=duration/1000
        val fmt=String.format("%02d:%02d:%02d",secs/3600,(secs%3600)/60,secs%60)
        paint.typeface=Typeface.create("sans-serif",Typeface.BOLD);paint.textSize=27*density
        paint.color=Color.WHITE;canvas.drawText(fmt,cx,cy+3*density,paint)
        paint.typeface=Typeface.DEFAULT;paint.textSize=14*density
        paint.color=Color.rgb(182,199,216);canvas.drawText(label,cx,cy+37*density,paint)
    }
}

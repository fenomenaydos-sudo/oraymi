package com.oraymi.nativeapp

import org.junit.Assert.*
import org.junit.Test

class IntentParserTest {
    @Test fun `pause synonyms and languages`() {
        listOf("Бадди, стоп", "Бадди поставь на паузу", "Buddy pause", "Бадди тоқта", "Бадди Halt", "Бадди остановись").forEach {
            assertEquals(it, IntentParser.Action.PAUSE, IntentParser.parse(it).action)
        }
    }
    @Test fun `finish is different from pause`() {
        assertEquals(IntentParser.Action.FINISH, IntentParser.parse("Бадди заверши занятие").action)
        assertEquals(IntentParser.Action.RESUME, IntentParser.parse("Бадди продолжай").action)
        assertEquals(IntentParser.Action.START, IntentParser.parse("Бадди начинай").action)
    }
    @Test fun `music and negation don't pause timer`() {
        assertEquals(IntentParser.Action.NONE, IntentParser.parse("Останови музыку").action)
        assertEquals(IntentParser.Action.WAKE, IntentParser.parse("Бадди не останавливай таймер").action)
        assertFalse(IntentParser.parse("стоп").hasWakeWord)
        assertEquals(IntentParser.Action.PAUSE, IntentParser.parse("Бадди не останавливай музыку, только тренировку поставь на паузу").action)
    }
    @Test fun `wake does not imply command`() {
        assertEquals(IntentParser.Action.WAKE, IntentParser.parse("Бадди").action)
    }
}

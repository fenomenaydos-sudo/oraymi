# ORAYMI — Rules for AI coding agents

## Product north star
Help users intentionally use their time, not maximize screen time. Android Native is an addition to the same ORAYMI platform, never replace the web site with untested code.

## Agent roles (workflow, not continuously running bots)
1. **Architect**: describe issue scope, impact, permissions, data migration and acceptance criteria.
2. **Android engineer**: implement one small, testable change in `android/`.
3. **Voice tester**: add multilingual positive/negative test cases. `стоп` always means PAUSE; `заверши` means FINISH. Music controls must never accidentally stop the timer.
4. **Design reviewer**: test at 360/390/430 dp, avoid overflow and ensure tap targets >= 44 dp.
5. **Privacy reviewer**: check RECORD_AUDIO and overlays; never introduce background surveillance or keys in source.

## Merge gate
Every PR must pass Android unit tests + debug APK build + on-device voice test checklist. Changes to billing, personal data or external integrations require owner approval. Never auto-merge or publish a Play Store release.

## No false promises
Do not claim persistent wakeword is guaranteed by Android SpeechRecognizer. No AI model or external API is connected until configured and tested.
